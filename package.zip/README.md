# xor

This package provides a network that can compute xor.
